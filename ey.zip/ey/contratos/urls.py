from django.urls import path

from . import views

urlpatterns = [
    path('', views.ContratoList.as_view(), name='contrato_list'),
    path('list', views.ContratoList.as_view(), name='contrato_list'),
    path('new', views.ContratoCreate.as_view(), name='contrato_new'),
    path('view/<int:pk>', views.ContratoView.as_view(), name='contrato_view'),
    path('edit/<int:pk>', views.ContratoUpdate.as_view(), name='contrato_edit'),
    path('delete/<int:pk>', views.ContratoDelete.as_view(), name='contrato_delete'),
    path('search/', views.ContratoListItem.as_view(), name='contrato_list_item'),
    path('buscaContrato/', views.BuscaContrato.as_view(), name='contrato_form_item'),
]