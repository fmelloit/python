from django.http import HttpResponse
from django.views.generic import ListView, DetailView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from contratos.models import Contrato
from .forms import ContratoForm, BuscaContratoForm

class ContratoList(ListView):
    model = Contrato
    paginate_by = 7

class ContratoListItem(ListView):
    model = Contrato
    paginate_by = 7
    template_name = 'contratos/contrato_list.html'

    def get_queryset(self):
        nome = self.request.GET.get('nome')
        return self.model.objects.filter(nome__icontains=nome)

class BuscaContrato(ListView):
    model = Contrato
    paginate_by = 7
    template_name = 'contratos/contrato_form_item.html'
    form_class = BuscaContratoForm
    success_url = reverse_lazy('contrato_list_item')

class ContratoView(DetailView):
    model = Contrato

class ContratoCreate(CreateView):
    form_class = ContratoForm
    template_name = 'contratos/contrato_form.html'
    success_url = reverse_lazy('contrato_list')

class ContratoUpdate(UpdateView):
    model = Contrato
    form_class = ContratoForm
    template_name = 'contratos/contrato_form.html'
    success_url = reverse_lazy('contrato_list')

class ContratoDelete(DeleteView):
    model = Contrato
    success_url = reverse_lazy('contrato_list')