from django.db import models
from django.urls import reverse

# Create your models here.
class Contrato(models.Model):
    nome = models.CharField(max_length=255)
    empresa = models.CharField(max_length=255)
    dataExpiracao = models.DateField()
    valor = models.DecimalField(max_digits=30,decimal_places=2)

    def __str__(self):
        return self.nome

    def get_absolute_url(self):
        return reverse('contrato_list', kwargs={'pk': self.pk})