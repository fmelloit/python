from django import forms

from .models import Contrato

class DateInput(forms.DateInput):
    input_type = 'date'

class ContratoForm(forms.ModelForm):

    class Meta:
        model = Contrato
        fields = ('__all__')
        widgets = {'dataExpiracao': DateInput()}

class BuscaContratoForm(forms.ModelForm):

    class Meta:
        model = Contrato
        fields = ('nome',)