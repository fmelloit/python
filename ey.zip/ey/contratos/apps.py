from django.apps import AppConfig


class ContratosConfig(AppConfig):
    name = 'contratos'
