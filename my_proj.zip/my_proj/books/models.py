from django.db import models
from django.urls import reverse

class Book(models.Model):
    name = models.CharField(max_length=200)
    pages = models.IntegerField()
    isbn = models.IntegerField(default=None, blank=True, null=True)
    editora = models.CharField(max_length=50,default="Campos")
    autor = models.CharField(max_length=100,default="Fernando Mello")
    capitulos = models.IntegerField(default=None, blank=True, null=True)

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse('book_edit', kwargs={'pk': self.pk})